import React from 'react';
import { MapPin, Search, ShoppingBag, User } from 'lucide-react';

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-8">
          <h1 className="text-2xl font-bold text-orange-500">Swiggy</h1>
          <div className="flex items-center space-x-2 text-gray-500 cursor-pointer hover:text-orange-500">
            <MapPin size={20} />
            <span className="font-medium">Select Location</span>
          </div>
        </div>
        
        <nav className="flex items-center space-x-6">
          <button className="flex items-center space-x-2 text-gray-700 hover:text-orange-500">
            <Search size={20} />
            <span>Search</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-700 hover:text-orange-500">
            <User size={20} />
            <span>Sign In</span>
          </button>
          <button className="flex items-center space-x-2 text-gray-700 hover:text-orange-500">
            <ShoppingBag size={20} />
            <span>Cart</span>
          </button>
        </nav>
      </div>
    </header>
  );
}