import React from 'react';
import { Star } from 'lucide-react';
import type { Restaurant } from '../types';

interface Props {
  restaurant: Restaurant;
}

export default function RestaurantCard({ restaurant }: Props) {
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-pointer">
      <div className="relative">
        <img 
          src={restaurant.image} 
          alt={restaurant.name}
          className="w-full h-48 object-cover"
        />
        {restaurant.promoted && (
          <div className="absolute top-2 left-2 bg-gradient-to-r from-black to-gray-800 text-white px-2 py-1 rounded text-sm">
            Promoted
          </div>
        )}
      </div>
      
      <div className="p-4">
        <h3 className="font-semibold text-lg text-gray-800">{restaurant.name}</h3>
        <div className="flex items-center mt-1">
          <div className="flex items-center bg-green-500 px-1 rounded">
            <Star size={14} className="text-white" />
            <span className="text-white text-sm ml-1">{restaurant.rating}</span>
          </div>
          <span className="mx-2 text-gray-400">•</span>
          <span className="text-gray-600">{restaurant.deliveryTime}</span>
        </div>
        <p className="text-gray-500 text-sm mt-1">{restaurant.cuisines.join(', ')}</p>
        <p className="text-gray-600 text-sm mt-1">{restaurant.priceForTwo}</p>
      </div>
    </div>
  );
}