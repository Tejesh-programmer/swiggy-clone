import React from 'react';
import RestaurantCard from './RestaurantCard';
import type { Restaurant } from '../types';

const RESTAURANTS: Restaurant[] = [
  {
    id: '1',
    name: 'The Burger Joint',
    image: 'https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=600',
    rating: 4.2,
    deliveryTime: '30-35 min',
    cuisines: ['American', 'Burgers', 'Fast Food'],
    priceForTwo: '₹400 for two',
    promoted: true
  },
  {
    id: '2',
    name: 'Pizza Paradise',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600',
    rating: 4.5,
    deliveryTime: '25-30 min',
    cuisines: ['Italian', 'Pizza', 'Fast Food'],
    priceForTwo: '₹500 for two',
    promoted: false
  },
  {
    id: '3',
    name: 'Biryani House',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=600',
    rating: 4.3,
    deliveryTime: '35-40 min',
    cuisines: ['Indian', 'Biryani', 'Mughlai'],
    priceForTwo: '₹600 for two',
    promoted: true
  },
  {
    id: '4',
    name: 'Healthy Bowl',
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600',
    rating: 4.1,
    deliveryTime: '20-25 min',
    cuisines: ['Healthy', 'Salads', 'Bowl'],
    priceForTwo: '₹350 for two',
    promoted: false
  }
];

export default function RestaurantList() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Restaurants near you</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {RESTAURANTS.map(restaurant => (
          <RestaurantCard key={restaurant.id} restaurant={restaurant} />
        ))}
      </div>
    </div>
  );
}