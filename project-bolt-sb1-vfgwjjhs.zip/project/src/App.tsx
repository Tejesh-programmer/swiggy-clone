import React from 'react';
import Header from './components/Header';
import RestaurantList from './components/RestaurantList';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main>
        <div className="bg-gradient-to-r from-orange-500 to-orange-600 py-12 px-4">
          <div className="max-w-6xl mx-auto">
            <h1 className="text-4xl font-bold text-white mb-4">
              Hungry? You're in the right place
            </h1>
            <p className="text-white text-lg opacity-90">
              Order food from the best restaurants in your area
            </p>
          </div>
        </div>
        <RestaurantList />
      </main>
    </div>
  );
}

export default App;